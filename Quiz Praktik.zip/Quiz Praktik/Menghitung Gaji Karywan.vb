﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox4.Text = Val(TextBox2.Text) + Val(TextBox3.Text)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("001")
        ComboBox1.Items.Add("002")
        ComboBox1.Items.Add("003")
        ComboBox1.Items.Add("004")
        ComboBox1.Items.Add("005")
        ComboBox1.Items.Add("006")

        ComboBox2.Items.Add("Direktur")
        ComboBox2.Items.Add("Manajer")
        ComboBox2.Items.Add("Karyawan")

        ComboBox3.Items.Add("001A")
        ComboBox3.Items.Add("001B")
        ComboBox3.Items.Add("001C")

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Select Case ComboBox1.Text
            Case "001"
                TextBox1.Text = "Galang"
            Case "002"
                TextBox1.Text = "Paul"
            Case "003"
                TextBox1.Text = "Tarjo"
            Case "004"
                TextBox1.Text = "Sugeng"
            Case "005"
                TextBox1.Text = "Dika"
            Case "006"
                TextBox1.Text = "Bruno"
            Case Else
                TextBox1.Text = ""

        End Select
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        Select Case ComboBox2.Text
            Case "Direktur"
                TextBox2.Text = 10000000
            Case "Manajer"
                TextBox2.Text = 8000000
            Case "Karyawan"
                TextBox2.Text = 5000000

        End Select
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox3.SelectedIndexChanged
        Select Case ComboBox3.Text
            Case "001A"
                TextBox3.Text = 3000000
            Case "001B"
                TextBox3.Text = 2500000
            Case "001C"
                TextBox3.Text = 1500000

        End Select
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""

        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim keluar As String
        keluar = MsgBox("Apakah anda ingin keluar??", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Exit")
        If keluar = vbOK Then
            Me.Close()
        End If
    End Sub
End Class
